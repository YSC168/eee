package com.ysc.demo;


import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.*;
import android.os.*;
import android.Manifest;
import android.annotation.TargetApi;
import android.content.ContentUris;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import com.zhuandian.gifview.*;
import java.io.*;
import android.view.*;
import android.app.*;
import com.sunglab.bigbanghd.*;


public class BearService extends Service {
	
    LinearLayout mFloatLayout;
    WindowManager.LayoutParams wmParams;
    WindowManager mWindowManager;
    GifView gifView;
    private static final String TAG = "BearService";
    private boolean longClick = false;
	private boolean Click;
	public void stopService()
	{
		// TODO: Implement this method
	}
    @Override
    public void onCreate() {
        super.onCreate();
        Log.i(TAG, "oncreat");
        createFloatView();
    }
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    private void createFloatView() {
        wmParams = new WindowManager.LayoutParams();
        mWindowManager = (WindowManager) getApplication().getSystemService(getApplication().WINDOW_SERVICE);
		wmParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_ERROR;   
        wmParams.format = PixelFormat.RGBA_8888;
        //设置浮动窗口不可聚焦（实现操作除浮动窗口外的其他可见窗口的操作）
		wmParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_FULLSCREEN| WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        //调整悬浮窗显示的停靠位置为左侧置顶
        wmParams.gravity = Gravity.LEFT | Gravity.TOP;

        // 以屏幕左上角为原点，设置x、y初始值
        wmParams.x = 360;
        wmParams.y = 640;

        wmParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
        wmParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        LayoutInflater inflater = LayoutInflater.from(getApplication());
        mFloatLayout = (LinearLayout) inflater.inflate(R.layout.float_view_bear, null);
        mWindowManager.addView(mFloatLayout, wmParams);
        Log.i(TAG, "mFloatLayout-->left" + mFloatLayout.getLeft());
        Log.i(TAG, "mFloatLayout-->right" + mFloatLayout.getRight());
        Log.i(TAG, "mFloatLayout-->top" + mFloatLayout.getTop());
        Log.i(TAG, "mFloatLayout-->bottom" + mFloatLayout.getBottom());
       gifView = (GifView) mFloatLayout.findViewById(R.id.float_id);
        mFloatLayout.measure(View.MeasureSpec.makeMeasureSpec(0,
															  View.MeasureSpec.UNSPECIFIED), View.MeasureSpec
							 .makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        Log.i(TAG, "Width/2--->" + gifView.getMeasuredWidth() / 2);
        Log.i(TAG, "Height/2--->" + gifView.getMeasuredHeight() / 2);
        gifView.setOnTouchListener(new OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
				//	if (longClick) {
						Log.i(TAG, "移动");
						wmParams.x = (int) event.getRawX() - gifView.getMeasuredWidth() / 2;
						wmParams.y = (int) event.getRawY() - gifView.getMeasuredHeight() / 2 ;
						mWindowManager.updateViewLayout(mFloatLayout, wmParams);
					//}
					return false;
				}
			});
        gifView.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View view) {
					Log.i(TAG, "长按");
					longClick = true;
				
					Intent dialogIntent = new Intent(getBaseContext(),s.class); 
					dialogIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 
					getApplication().startActivity(dialogIntent); 		
					
					return false;
				}
			});
        gifView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					Log.i(TAG, "点击");
					longClick=false;
			
					

				

					
				}
			});
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mFloatLayout != null) {
            mWindowManager.removeView(mFloatLayout);
        }
    }


	
}



