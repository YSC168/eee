package com.ysc.demo;

import android.app.*;
import android.os.*;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.view.View;
import android.content.Intent;
import com.android.permission.*;
import android.view.*;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.WindowManager;
import android.widget.VideoView;
import com.sunglab.bigbanghd.*;

public class MainActivity extends Activity 
{
	
	private BalloonRelativeLayout mBalloonRelativeLayout;

    private int TIME = 100;//这里默认每隔100毫秒添加一个气泡
    Handler mHandler = new Handler();
    Runnable runnable = new Runnable() {

        @Override
        public void run() {
            // handler自带方法实现定时器
            try {
                mHandler.postDelayed(this, TIME);
                mBalloonRelativeLayout.addBalloon();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		
		
		
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		mBalloonRelativeLayout = (BalloonRelativeLayout) findViewById(R.id.balloonRelativeLayout);
		//mHandler.postDelayed(runnable, TIME);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		FloatWindowManager.getInstance().applyOrShowFloatWindow(MainActivity.this);
		Button magic = (Button)findViewById(R.id.magic);
		Button pic = (Button)findViewById(R.id.picture);
		Button bear = (Button)findViewById(R.id.bear);
		Button bearc = (Button)findViewById(R.id.bearc);
		//FloatingWindowActivity的布局视图按钮
        Button start = (Button)findViewById(R.id.start_id);
		Button starta = (Button)findViewById(R.id.starta_id);
		Button startb = (Button)findViewById(R.id.startb_id);
		Button startc = (Button)findViewById(R.id.startc_id);
		Button startd = (Button)findViewById(R.id.startd_id);
		Button startg = (Button)findViewById(R.id.startg_id);
		Button startag = (Button)findViewById(R.id.startag_id);
		Button startbg = (Button)findViewById(R.id.startbg_id);
		Button startcg = (Button)findViewById(R.id.startcg_id);
		Button startdg = (Button)findViewById(R.id.startdg_id);
        Button remove = (Button)findViewById(R.id.remove_id);

		magic.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v)
				{
					Intent intent=new Intent(MainActivity.this,s.class);
					startActivity(intent);
								  					
				}
			});
		pic.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v)
				{
					Intent intent = new Intent(MainActivity.this,Img.class);
					startActivity(intent);
					
				}
			});
		bear.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v)
				{
					Intent intent = new Intent(MainActivity.this, BearService.class);
					startService(intent);
					finish();
				}
			});
		bearc.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v)
				{
					Intent intent = new Intent(MainActivity.this, BearService.class);
					stopService(intent);
				}
			});
        start.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v)
				{
					Intent intent = new Intent(MainActivity.this, BallService.class);
					startService(intent);
				}
			});
		startg.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v)
				{
					Intent intent = new Intent(MainActivity.this, BallService.class);
					stopService(intent);
				}
			});
		starta.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v)
				{
					Intent intent = new Intent(MainActivity.this, SnowflakeService.class);
					startService(intent);
				}
			});
		startag.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v)
				{
					Intent intent = new Intent(MainActivity.this, SnowflakeService.class);
					stopService(intent);

				}
			});
		startb.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v)
				{
					Intent intent = new Intent(MainActivity.this, HeartService.class);
					startService(intent);
				}
			});
		startbg.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v)
				{
					Intent intent = new Intent(MainActivity.this, HeartService.class);
					stopService(intent);
				}
			});
		startc.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v)
				{
					Intent intent = new Intent(MainActivity.this, PictureService.class);
					startService(intent);
				}
			});
		startcg.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v)
				{
					Intent intent = new Intent(MainActivity.this, PictureService.class);
					stopService(intent);
				}
			});
		startd.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v)
				{
					Intent intent = new Intent(MainActivity.this, BalloonService.class);
					startService(intent);
				}
			});
		startdg.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v)
				{
					Intent intent = new Intent(MainActivity.this, BalloonService.class);
					stopService(intent);
				}
			});
        remove.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v)
				{
					Intent intentc = new Intent(MainActivity.this, SnowflakeService.class);
					stopService(intentc);
					Intent intenta = new Intent(MainActivity.this, HeartService.class);
					stopService(intenta);
					Intent intent = new Intent(MainActivity.this, BallService.class);
					stopService(intent);
					Intent intentd = new Intent(MainActivity.this, BalloonService.class);
					stopService(intentd);
					Intent intentb = new Intent(MainActivity.this, PictureService.class);
					stopService(intentb);
					Intent intentbr = new Intent(MainActivity.this, BearService.class);
					stopService(intentbr);
				}
			});	
    }
	
}
