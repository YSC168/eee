package com.ysc.demo;


import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.*;
import android.os.*;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.WindowManager;
import android.widget.VideoView;


public class BalloonService extends Service {
    LinearLayout mFloatLayout;
	private BalloonRelativeLayout mBalloonRelativeLayout;
    WindowManager.LayoutParams wmParams;
    WindowManager mWindowManager;
    ImageView mFloatView;
    private static final String TAG = "PictureService";
    private boolean longClick = false;
	private boolean Click;

	
    private int TIME = 400;//这里默认每隔100毫秒添加一个气泡
    Handler mHandler = new Handler();
    Runnable runnable = new Runnable() {

        @Override
        public void run() {
            // handler自带方法实现定时器
            try {
                mHandler.postDelayed(this, TIME);
				
                mBalloonRelativeLayout.addBalloon();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };
	public void stopService()
	{
		// TODO: Implement this method
	};
	


	
	
    @Override
    public void onCreate() {
        super.onCreate();
        Log.i(TAG, "oncreat");
		
		
        createFloatView();
		mHandler.postDelayed(runnable, TIME);
	
   
		
    }
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    private void createFloatView() {
        wmParams = new WindowManager.LayoutParams();
        mWindowManager = (WindowManager) getApplication().getSystemService(getApplication().WINDOW_SERVICE);
		wmParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_ERROR;   
        wmParams.format = PixelFormat.RGBA_8888;
        //设置浮动窗口不可聚焦（实现操作除浮动窗口外的其他可见窗口的操作）
		wmParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|WindowManager.LayoutParams.FLAG_FULLSCREEN| WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        //调整悬浮窗显示的停靠位置为左侧置顶
        wmParams.gravity = Gravity.LEFT | Gravity.TOP;

        // 以屏幕左上角为原点，设置x、y初始值
        wmParams.x = 360;
        wmParams.y = 640;

        wmParams.width = WindowManager.LayoutParams.MATCH_PARENT;
        wmParams.height = WindowManager.LayoutParams.MATCH_PARENT;
        LayoutInflater inflater = LayoutInflater.from(getApplication());
        mFloatLayout = (LinearLayout) inflater.inflate(R.layout.float_view_balloon, null);
		mBalloonRelativeLayout = (BalloonRelativeLayout) mFloatLayout.findViewById(R.id.balloonRelativeLayout);
		mHandler.postDelayed(runnable, TIME);
		
        mWindowManager.addView(mFloatLayout, wmParams);


    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mFloatLayout != null) {
            mWindowManager.removeView(mFloatLayout);
        }
    }
}

